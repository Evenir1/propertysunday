# Listing Model
from flask_sqlalchemy import SQLAlchemy
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Check if db is already defined (e.g. by a test runner or another import)
if 'db' not in globals():
    db = SQLAlchemy()

class Listing(db.Model):
    __tablename__ = 'listings'

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=True)
    price = db.Column(db.Numeric(10, 2), nullable=False) # Assuming price in ZAR, adjust precision as needed
    address = db.Column(db.String(255), nullable=False)
    city = db.Column(db.String(100), nullable=True)
    province = db.Column(db.String(100), nullable=True) # Relevant for South Africa
    postal_code = db.Column(db.String(10), nullable=True)
    latitude = db.Column(db.Float, nullable=True)
    longitude = db.Column(db.Float, nullable=True)
    bedrooms = db.Column(db.Integer, nullable=True)
    bathrooms = db.Column(db.Numeric(3, 1), nullable=True) # e.g., 2.5 bathrooms
    property_type = db.Column(db.String(50), nullable=True) # e.g., House, Apartment, Townhouse
    area_sqm = db.Column(db.Integer, nullable=True) # Size in square meters
    # image_urls = db.Column(db.JSON, nullable=True) # Store as a list of URLs
    main_image_url = db.Column(db.String(500), nullable=True)
    # For multiple images, a separate Image model with a foreign key to Listing might be better

    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    user = db.relationship('User', backref=db.backref('listings', lazy=True))

    source = db.Column(db.String(50), nullable=False, default='manual') # e.g., manual, property24, privateproperty
    status = db.Column(db.String(50), default='active', nullable=False) # e.g., active, pending, sold, rented
    is_charged_listing = db.Column(db.Boolean, default=False, nullable=False)
    listing_tier = db.Column(db.String(50), nullable=True) # e.g., standard, premium

    date_posted = db.Column(db.DateTime, server_default=db.func.now())
    date_updated = db.Column(db.DateTime, server_default=db.func.now(), onupdate=db.func.now())

    def __init__(self, title, price, address, user_id, description=None, city=None, province=None, postal_code=None, latitude=None, longitude=None, bedrooms=None, bathrooms=None, property_type=None, area_sqm=None, main_image_url=None, source='manual', status='active', is_charged_listing=False, listing_tier=None):
        self.title = title
        self.description = description
        self.price = price
        self.address = address
        self.city = city
        self.province = province
        self.postal_code = postal_code
        self.latitude = latitude
        self.longitude = longitude
        self.bedrooms = bedrooms
        self.bathrooms = bathrooms
        self.property_type = property_type
        self.area_sqm = area_sqm
        self.main_image_url = main_image_url
        self.user_id = user_id
        self.source = source
        self.status = status
        self.is_charged_listing = is_charged_listing
        self.listing_tier = listing_tier

    def __repr__(self):
        return f'<Listing {self.id}: {self.title}>'

    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'price': str(self.price), # Convert Decimal to string for JSON serialization
            'address': self.address,
            'city': self.city,
            'province': self.province,
            'postal_code': self.postal_code,
            'latitude': self.latitude,
            'longitude': self.longitude,
            'bedrooms': self.bedrooms,
            'bathrooms': str(self.bathrooms) if self.bathrooms else None,
            'property_type': self.property_type,
            'area_sqm': self.area_sqm,
            'main_image_url': self.main_image_url,
            'user_id': self.user_id,
            'agent_details': self.user.to_dict() if self.user else None, # Include agent/user details
            'source': self.source,
            'status': self.status,
            'is_charged_listing': self.is_charged_listing,
            'listing_tier': self.listing_tier,
            'date_posted': self.date_posted.isoformat() if self.date_posted else None,
            'date_updated': self.date_updated.isoformat() if self.date_updated else None
        }

