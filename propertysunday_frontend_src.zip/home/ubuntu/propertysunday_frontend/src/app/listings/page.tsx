"use client";

import React, { useEffect, useState, useCallback } from 'react';
import Link from 'next/link';

interface Listing {
    id: number;
    title: string;
    price: string;
    address: string;
    city?: string;
    province?: string;
    bedrooms?: number;
    bathrooms?: string;
    property_type?: string;
    main_image_url?: string;
    agent_details?: { full_name?: string; email?: string };
}

interface ApiResponse {
    listings: Listing[];
    total_pages: number;
    current_page: number;
    total_listings: number;
    message?: string;
}

interface SearchFilters {
    search?: string;
    city?: string;
    province?: string;
    property_type?: string;
    min_price?: string;
    max_price?: string;
    bedrooms?: string;
}

async function fetchListings(page = 1, perPage = 9, filters: SearchFilters = {}): Promise<ApiResponse | null> {
    try {
        const queryParams = new URLSearchParams({
            page: page.toString(),
            per_page: perPage.toString(),
        });

        for (const [key, value] of Object.entries(filters)) {
            if (value) {
                queryParams.append(key, value);
            }
        }
        
        const response = await fetch(`http://localhost:5000/listings?${queryParams.toString()}`);
        if (!response.ok) {
            console.error("Failed to fetch listings:", response.statusText);
            const errorData = await response.json();
            throw new Error(errorData.message || response.statusText);
        }
        return await response.json();
    } catch (error) {
        console.error("Error fetching listings:", error);
        throw error; // Re-throw to be caught by the component
    }
}

export default function ListingsPage() {
    const [listingsData, setListingsData] = useState<ApiResponse | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [currentPage, setCurrentPage] = useState(1);
    const [filters, setFilters] = useState<SearchFilters>({});

    const loadListings = useCallback(async (pageToLoad: number, currentFilters: SearchFilters) => {
        setLoading(true);
        setError(null);
        try {
            const data = await fetchListings(pageToLoad, 9, currentFilters);
            setListingsData(data);
        } catch (err: any) {
            setError(err.message || "Could not load listings. Please try again later.");
            setListingsData(null); // Clear previous data on error
        }
        setLoading(false);
    }, []);

    useEffect(() => {
        loadListings(currentPage, filters);
    }, [currentPage, filters, loadListings]);

    const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFilters(prev => ({ ...prev, [name]: value }));
    };

    const handleSearchSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setCurrentPage(1); // Reset to first page on new search
        loadListings(1, filters); // Trigger load with current filters
    };

    const handleNextPage = () => {
        if (listingsData && currentPage < listingsData.total_pages) {
            setCurrentPage(currentPage + 1);
        }
    };

    const handlePreviousPage = () => {
        if (currentPage > 1) {
            setCurrentPage(currentPage - 1);
        }
    };
    
    const propertyTypesSA = ["House", "Apartment", "Townhouse", "Vacant Land", "Farm", "Commercial Property", "Industrial Property"];

    return (
        <div className="min-h-screen bg-gray-50 p-4 md:p-8">
            <header className="mb-8 text-center">
                <h1 className="text-4xl font-bold text-gray-800">Property Listings</h1>
                <p className="text-lg text-gray-600">Explore properties across South Africa</p>
            </header>

            {/* Search and Filter Bar */}
            <div className="mb-10 p-6 bg-white rounded-lg shadow-md">
                <form onSubmit={handleSearchSubmit} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 items-end">
                    <div className="col-span-1 md:col-span-2 lg:col-span-3 xl:col-span-4">
                        <label htmlFor="search" className="block text-sm font-medium text-gray-700">Search by Keyword</label>
                        <input
                            type="text"
                            name="search"
                            id="search"
                            placeholder="e.g., Sandton, 3 bedroom, sea view"
                            value={filters.search || ""}
                            onChange={handleFilterChange}
                            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                        />
                    </div>
                    
                    <div>
                        <label htmlFor="city" className="block text-sm font-medium text-gray-700">City</label>
                        <input type="text" name="city" id="city" placeholder="e.g., Cape Town" value={filters.city || ""} onChange={handleFilterChange} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
                    </div>
                    <div>
                        <label htmlFor="province" className="block text-sm font-medium text-gray-700">Province</label>
                        <input type="text" name="province" id="province" placeholder="e.g., Gauteng" value={filters.province || ""} onChange={handleFilterChange} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
                    </div>
                    <div>
                        <label htmlFor="property_type" className="block text-sm font-medium text-gray-700">Property Type</label>
                        <select name="property_type" id="property_type" value={filters.property_type || ""} onChange={handleFilterChange} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm bg-white">
                            <option value="">All Types</option>
                            {propertyTypesSA.map(type => <option key={type} value={type}>{type}</option>)}
                        </select>
                    </div>
                    <div>
                        <label htmlFor="bedrooms" className="block text-sm font-medium text-gray-700">Bedrooms</label>
                        <input type="number" name="bedrooms" id="bedrooms" placeholder="e.g., 3" value={filters.bedrooms || ""} onChange={handleFilterChange} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" min="0"/>
                    </div>
                    <div>
                        <label htmlFor="min_price" className="block text-sm font-medium text-gray-700">Min Price (R)</label>
                        <input type="number" name="min_price" id="min_price" placeholder="e.g., 500000" value={filters.min_price || ""} onChange={handleFilterChange} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" min="0"/>
                    </div>
                    <div>
                        <label htmlFor="max_price" className="block text-sm font-medium text-gray-700">Max Price (R)</label>
                        <input type="number" name="max_price" id="max_price" placeholder="e.g., 2000000" value={filters.max_price || ""} onChange={handleFilterChange} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" min="0"/>
                    </div>
                    <div className="col-span-1 md:col-span-2 lg:col-span-1 flex items-end">
                        <button type="submit" className="w-full bg-terracotta-red text-white py-2 px-4 rounded-md hover:bg-terracotta-red-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-terracotta-red-light transition-colors duration-300">
                            Search Properties
                        </button>
                    </div>
                </form>
            </div>

            {loading && <div className="text-center py-10"><p className="text-xl">Loading listings...</p></div>}
            {error && <div className="text-center py-10"><p className="text-xl text-red-500">{error}</p></div>}
            
            {!loading && !error && listingsData && listingsData.listings.length === 0 && (
                <div className="text-center py-10"><p className="text-xl text-gray-600">No listings found matching your criteria. Try adjusting your filters.</p></div>
            )}

            {!loading && !error && listingsData && listingsData.listings.length > 0 && (
                <div className="container mx-auto">
                    <div className="mb-4 text-sm text-gray-600">
                        Showing {listingsData.listings.length} of {listingsData.total_listings} results.
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                        {listingsData.listings.map((listing) => (
                            <div key={listing.id} className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300 ease-in-out flex flex-col">
                                {listing.main_image_url ? (
                                    <img src={listing.main_image_url} alt={listing.title} className="w-full h-56 object-cover" />
                                ) : (
                                    <div className="w-full h-56 bg-gray-200 flex items-center justify-center text-gray-500">No Image Available</div>
                                )}
                                <div className="p-6 flex flex-col flex-grow">
                                    <h2 className="text-xl lg:text-2xl font-semibold text-terracotta-red mb-2 truncate" title={listing.title}>{listing.title}</h2>
                                    <p className="text-xl lg:text-2xl font-bold text-gray-900 mb-2">R {parseFloat(listing.price).toLocaleString("en-ZA")}</p>
                                    <p className="text-gray-700 mb-1 truncate text-sm"><span className="font-medium">Address:</span> {listing.address}</p>
                                    {listing.city && <p className="text-gray-600 text-xs mb-1"><span className="font-medium">City:</span> {listing.city}</p>}
                                    {listing.province && <p className="text-gray-600 text-xs mb-3"><span className="font-medium">Province:</span> {listing.province}</p>}
                                    
                                    <div className="flex justify-between items-center text-xs text-gray-600 mb-4">
                                        {listing.bedrooms != null && <span><span className="font-bold">{listing.bedrooms}</span> Bed</span>}
                                        {listing.bathrooms != null && <span><span className="font-bold">{listing.bathrooms}</span> Bath</span>}
                                    </div>
                                    
                                    <div className="mt-auto">
                                        <Link href={`/listings/${listing.id}`} legacyBehavior>
                                            <a className="block w-full text-center bg-terracotta-red text-white py-2 px-4 rounded hover:bg-terracotta-red-dark transition-colors duration-300 text-sm font-medium">
                                                View Details
                                            </a>
                                        </Link>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>

                    {/* Pagination Controls */}
                    {listingsData.total_pages > 1 && (
                        <div className="mt-12 flex justify-center items-center space-x-4">
                            <button 
                                onClick={handlePreviousPage} 
                                disabled={currentPage === 1 || loading}
                                className="px-4 py-2 bg-gray-300 text-gray-700 rounded hover:bg-gray-400 disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                Previous
                            </button>
                            <span className="text-gray-700">Page {listingsData.current_page} of {listingsData.total_pages}</span>
                            <button 
                                onClick={handleNextPage} 
                                disabled={currentPage === listingsData.total_pages || loading}
                                className="px-4 py-2 bg-gray-300 text-gray-700 rounded hover:bg-gray-400 disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                Next
                            </button>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
}

